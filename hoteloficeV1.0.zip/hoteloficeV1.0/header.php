<!doctype html> 
<html <?php language_attributes(); ?>> 
    <head> 
        <!-- Define Charset -->         
        <meta charset="<?php bloginfo( 'charset' ); ?>"> 
        <!-- Page Title -->                  
        <!-- Responsive Metatag -->         
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <!-- Page Description and Author -->         
        <meta name="description" content="Miami luxury hotel, Plaza Hotel, offers hotel packages as memorably grand as our destination"> 
        <meta name="author" content="CoralixThemes"> 
        <!-- Stylesheet
	===================================================================================================	 -->         
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->         
        <!-- Bootstrap -->                           
        <!-- Grid galery -->         
        <noscript>
</noscript>         
        <!--[if lt IE 9]><link rel="stylesheet" type="text/css" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/grid/fallback.css" /><![endif]-->         
        <!-- styles radios checkboxes -->         
        <!--[if IE 7]><link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/jstyling-ie7Fixes.css" type="text/css" media="screen" /><![endif]-->         
        <!-- Custom Template Styles -->                  
        <!-- Media Queries -->                  
        <!-- Fav and touch icons -->         
        <link rel="shortcut icon" href="<?php echo esc_url( get_template_directory_uri() ); ?>/img/icons/favicon.ico"> 
        <link rel="apple-touch-icon" href="<?php echo esc_url( get_template_directory_uri() ); ?>/img/icons/apple-touch-icon.png"> 
        <link rel="apple-touch-icon" sizes="72x72" href="<?php echo esc_url( get_template_directory_uri() ); ?>/img/icons/apple-touch-icon-72x72.png"> 
        <link rel="apple-touch-icon" sizes="114x114" href="<?php echo esc_url( get_template_directory_uri() ); ?>/img/icons/apple-touch-icon-114x114.png"> 
        <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
        <?php wp_head(); ?>
    </head>     
    <body>