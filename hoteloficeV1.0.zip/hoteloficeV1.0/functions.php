<?php
if ( ! function_exists( 'hotel_of_ice_setup' ) ) :

function hotel_of_ice_setup() {

    /*
     * Make theme available for translation.
     * Translations can be filed in the /languages/ directory.
     */
    /* Pinegrow generated Load Text Domain Begin */
    load_theme_textdomain( 'hotel_of_ice', get_template_directory() . '/languages' );
    /* Pinegrow generated Load Text Domain End */

    // Add default posts and comments RSS feed links to head.
    add_theme_support( 'automatic-feed-links' );

    /*
     * Let WordPress manage the document title.
     */
    add_theme_support( 'title-tag' );
    
    /*
     * Enable support for Post Thumbnails on posts and pages.
     */
    add_theme_support( 'post-thumbnails' );
    set_post_thumbnail_size( 825, 510, true );

    // Add menus.
    register_nav_menus( array(
        'primary' => __( 'Primary Menu', 'hotel_of_ice' ),
        'social'  => __( 'Social Links Menu', 'hotel_of_ice' ),
    ) );

    /*
     * Switch default core markup for search form, comment form, and comments
     * to output valid HTML5.
     */
    add_theme_support( 'html5', array(
        'search-form', 'comment-form', 'comment-list', 'gallery', 'caption'
    ) );

    /*
     * Enable support for Post Formats.
     */
    add_theme_support( 'post-formats', array(
        'aside', 'image', 'video', 'quote', 'link', 'gallery', 'status', 'audio', 'chat'
    ) );
}
endif; // hotel_of_ice_setup

add_action( 'after_setup_theme', 'hotel_of_ice_setup' );


if ( ! function_exists( 'hotel_of_ice_init' ) ) :

function hotel_of_ice_init() {

    
    // Use categories and tags with attachments
    register_taxonomy_for_object_type( 'category', 'attachment' );
    register_taxonomy_for_object_type( 'post_tag', 'attachment' );

    /*
     * Register custom post types. You can also move this code to a plugin.
     */
    /* Pinegrow generated Custom Post Types Begin */

    /* Pinegrow generated Custom Post Types End */
    
    /*
     * Register custom taxonomies. You can also move this code to a plugin.
     */
    /* Pinegrow generated Taxonomies Begin */

    /* Pinegrow generated Taxonomies End */

}
endif; // hotel_of_ice_setup

add_action( 'init', 'hotel_of_ice_init' );


if ( ! function_exists( 'hotel_of_ice_widgets_init' ) ) :

function hotel_of_ice_widgets_init() {

    /*
     * Register widget areas.
     */
    /* Pinegrow generated Register Sidebars Begin */

    /* Pinegrow generated Register Sidebars End */
}
add_action( 'widgets_init', 'hotel_of_ice_widgets_init' );
endif;// hotel_of_ice_widgets_init



if ( ! function_exists( 'hotel_of_ice_customize_register' ) ) :

function hotel_of_ice_customize_register( $wp_customize ) {
    // Do stuff with $wp_customize, the WP_Customize_Manager object.

    /* Pinegrow generated Customizer Controls Begin */

    /* Pinegrow generated Customizer Controls End */

}
add_action( 'customize_register', 'hotel_of_ice_customize_register' );
endif;// hotel_of_ice_customize_register


if ( ! function_exists( 'hotel_of_ice_enqueue_scripts' ) ) :
    function hotel_of_ice_enqueue_scripts() {

        /* Pinegrow generated Enqueue Scripts Begin */

    wp_deregister_script( 'jquery' );
    wp_enqueue_script( 'jquery', get_template_directory_uri() . '/js/jquery-1.8.2.min.js', false, null, true);

    wp_deregister_script( 'bootstrap' );
    wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/js/bootstrap.js', false, null, true);

    wp_deregister_script( 'bootstrapselect' );
    wp_enqueue_script( 'bootstrapselect', get_template_directory_uri() . '/js/bootstrap-select.min.js', false, null, true);

    wp_deregister_script( 'modernizrcustom' );
    wp_enqueue_script( 'modernizrcustom', get_template_directory_uri() . '/js/modernizr.custom.26633.js', false, null, true);

    wp_deregister_script( 'jquerygridrotator' );
    wp_enqueue_script( 'jquerygridrotator', get_template_directory_uri() . '/js/jquery.gridrotator.js', false, null, true);

    wp_deregister_script( 'responsiveslides' );
    wp_enqueue_script( 'responsiveslides', get_template_directory_uri() . '/js/responsiveslides.min.js', false, null, true);

    wp_deregister_script( 'jquerytylingjs' );
    wp_enqueue_script( 'jquerytylingjs', get_template_directory_uri() . '/js/jquery.jstyling.min.js', false, null, true);

    wp_deregister_script( 'jqueryfitvids' );
    wp_enqueue_script( 'jqueryfitvids', get_template_directory_uri() . '/js/jquery.fitvids.min.js', false, null, true);

    wp_deregister_script( 'easing' );
    wp_enqueue_script( 'easing', get_template_directory_uri() . '/js/easing.js', false, null, true);

    wp_deregister_script( 'jqueryuitotop' );
    wp_enqueue_script( 'jqueryuitotop', get_template_directory_uri() . '/js/jquery.ui.totop.min.js', false, null, true);

    wp_deregister_script( 'waypoints' );
    wp_enqueue_script( 'waypoints', get_template_directory_uri() . '/js/waypoints.min.js', false, null, true);

    wp_deregister_script( 'jqueryfunc' );
    wp_enqueue_script( 'jqueryfunc', get_template_directory_uri() . '/js/jquery-func.js', false, null, true);

    /* Pinegrow generated Enqueue Scripts End */

        /* Pinegrow generated Enqueue Styles Begin */

    wp_deregister_style( 'bootstrap' );
    wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/css/bootstrap/bootstrap.min.css', false, null, 'screen');

    wp_deregister_style( 'bootstrapresponsive' );
    wp_enqueue_style( 'bootstrapresponsive', get_template_directory_uri() . '/css/bootstrap/bootstrap-responsive.min.css', false, null, 'screen');

    wp_deregister_style( 'fallback' );
    wp_enqueue_style( 'fallback', get_template_directory_uri() . '/css/grid/fallback.css', false, null, 'all');

    wp_deregister_style( 'style' );
    wp_enqueue_style( 'style', get_template_directory_uri() . '/css/style.css', false, null, 'screen');

    wp_deregister_style( 'mediaqueries' );
    wp_enqueue_style( 'mediaqueries', get_template_directory_uri() . '/css/media-queries.css', false, null, 'screen');

    /* Pinegrow generated Enqueue Styles End */

    }
    add_action( 'wp_enqueue_scripts', 'hotel_of_ice_enqueue_scripts' );
endif;

/*
 * Resource files included by Pinegrow.
 */
/* Pinegrow generated Include Resources Begin */

    /* Pinegrow generated Include Resources End */
?>