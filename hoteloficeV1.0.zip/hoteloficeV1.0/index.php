<?php
get_header(); ?>

<header> 
    <div class="container clearfix"> 
        <!--logo-->                 
        <a href="./" id="logo" class="pull-left"> 
            <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/logo.png" alt="logo"> 
        </a>                 
        <p class="slogan pull-left nmB"><?php bloginfo( 'description' ); ?></p> 
        <div class="pull-right"> 
            <div id="lang-menu" class="btn-group pull-right"> 
                <a class="btn dropdown-toggle" data-toggle="dropdown" href="#"> 
                    <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/flags/us.png" alt="" /> 
                    <span class="caret"></span> 
                </a>                         
                <ul class="dropdown-menu"> 
                    <li>
                        <a href="">
                            <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/flags/us.png" alt="" />
                            <?php _e( 'USA', 'hotel_of_ice' ); ?>
                        </a>
                    </li>                             
                    <li>
                        <a href="">
                            <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/flags/es.png" alt="" />
                            <?php _e( 'Spain', 'hotel_of_ice' ); ?>
                        </a>
                    </li>                             
                    <li>
                        <a href="">
                            <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/flags/br.png" alt="" />
                            <?php _e( 'Brazil', 'hotel_of_ice' ); ?>
                        </a>
                    </li>                             
                    <li>
                        <a href="">
                            <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/flags/jp.png" alt="" />
                            <?php _e( 'Japan', 'hotel_of_ice' ); ?>
                        </a>
                    </li>                             
                    <li>
                        <a href="">
                            <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/flags/id.png" alt="" />
                            <?php _e( 'Indonesia', 'hotel_of_ice' ); ?>
                        </a>
                    </li>                             
                    <li>
                        <a href="">
                            <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/flags/ca.png" alt="" />
                            <?php _e( 'Canada', 'hotel_of_ice' ); ?>
                        </a>
                    </li>                             
                    <li>
                        <a href="">
                            <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/flags/ro.png" alt="" />
                            <?php _e( 'Romania', 'hotel_of_ice' ); ?>
                        </a>
                    </li>                             
                    <li>
                        <a href="">
                            <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/flags/fi.png" alt="" />
                            <?php _e( 'Finland', 'hotel_of_ice' ); ?>
                        </a>
                    </li>                             
                </ul>                         
            </div>                     
            <div class="btn-login pull-right"> 
                <a href="#"><span class="toggle"></span><span class="toggleText"><?php _e( 'Member Login', 'hotel_of_ice' ); ?></span></a> 
                <form class="form-inline"> 
                    <div class="input-prepend"> 
                        <span class="add-on"><i class="icon-user"></i></span> 
                        <input class="span2" id="prependedInput" type="text" placeholder="Username"> 
                    </div>                             
                    <div class="input-prepend"> 
                        <span class="add-on"><i class="icon-lock"></i></span> 
                        <input id="prependedInput2" type="password" class="span2 input-small" placeholder="Password"> 
                    </div>                             
                    <button type="submit" class="btn">
                        <?php _e( 'Sign in', 'hotel_of_ice' ); ?>
                    </button>                             
                </form>                         
            </div>                     
        </div>                 
    </div>             
</header>
<section class="join-form"> 
    <div class="slider-container"> 
        <ul class="rslides" id="slider"> 
            <li>
                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/slider/img-1.jpg" alt="//" />
            </li>                     
            <li>
                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/slider/img-2.jpg" alt="//" />
            </li>                     
            <li>
                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/slider/img-1.jpg" alt="//" />
            </li>                     
        </ul>                 
    </div>             
    <div class="container"> 
        <div class="row-fluid"> 
            <div class="span12"> 
                <div class="form-container pull-right box animated pulse"> 
                    <form id="joinForm" action="<?php echo esc_url( get_template_directory_uri() ); ?>/join.php" method="post" accept-charset="utf-8"> 
                        <fieldset> 
                            <legend class="text-center nb nm">
                                <span><?php _e( 'june promotion', 'hotel_of_ice' ); ?></span>
                            </legend>                                     
                            <p class="text-center"><?php _e( 'Get the 3rd Night Free! All June 2013!', 'hotel_of_ice' ); ?></p> 
                            <div class="row-fluid"> 
                                <div class="span12"> 
                                    <select name="month" class="selectpicker span12"> 
                                        <option>
                                            <?php _e( 'Select your Room', 'hotel_of_ice' ); ?>
                                        </option>                                                 
                                        <option>
                                            <?php _e( 'Single Room', 'hotel_of_ice' ); ?>
                                        </option>                                                 
                                        <option>
                                            <?php _e( 'Double Room', 'hotel_of_ice' ); ?>
                                        </option>                                                 
                                        <option>
                                            <?php _e( 'Luxury Room', 'hotel_of_ice' ); ?>
                                        </option>                                                 
                                    </select>                                             
                                </div>                                         
                            </div>                                     
                            <div class="row-fluid"> 
                                <h4 class="span12"><?php _e( 'Please select the day you will arrived:', 'hotel_of_ice' ); ?></h4> 
                            </div>                                     
                            <div class="row-fluid"> 
                                <div class="span6"> 
                                    <div class="row-fluid"> 
                                        <select name="month" class="selectpicker span12"> 
                                            <option>
                                                <?php _e( 'Month', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( 'January', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( 'February', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( 'March', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( 'April', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( 'May', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( 'June', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( 'July', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( 'August', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( 'September', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( 'October', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( 'November', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( 'December', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                        </select>                                                 
                                    </div>                                             
                                </div>                                         
                                <div class="span3"> 
                                    <div class="row-fluid"> 
                                        <select name="day" class="selectpicker span12"> 
                                            <option>
                                                <?php _e( 'day', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '1', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '2', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '3', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '4', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '5', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '6', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '7', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '8', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '9', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '10', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '11', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '12', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '13', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '14', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '15', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '16', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '17', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '18', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '19', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '20', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '21', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '22', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '23', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '24', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '25', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '26', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '27', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '28', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '29', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '30', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '31', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                        </select>                                                 
                                    </div>                                             
                                </div>                                         
                                <div class="span3"> 
                                    <div class="row-fluid"> 
                                        <select name="year" class="selectpicker span12"> 
                                            <option>
                                                <?php _e( 'Year', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '2009', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '2010', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '2011', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '2012', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '2013', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '2014', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '2015', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '2016', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '2017', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '2018', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                        </select>                                                 
                                    </div>                                             
                                </div>                                         
                            </div>                                     
                            <div class="row-fluid"> 
                                <h4 class="span12"><?php _e( 'Please select the departure day:', 'hotel_of_ice' ); ?></h4> 
                            </div>                                     
                            <div class="row-fluid"> 
                                <div class="span6"> 
                                    <div class="row-fluid"> 
                                        <select name="month" class="selectpicker span12"> 
                                            <option>
                                                <?php _e( 'Month', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( 'January', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( 'February', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( 'March', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( 'April', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( 'May', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( 'June', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( 'July', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( 'August', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( 'September', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( 'October', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( 'November', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( 'December', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                        </select>                                                 
                                    </div>                                             
                                </div>                                         
                                <div class="span3"> 
                                    <div class="row-fluid"> 
                                        <select name="day" class="selectpicker span12"> 
                                            <option>
                                                <?php _e( 'day', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '1', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '2', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '3', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '4', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '5', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '6', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '7', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '8', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '9', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '10', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '11', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '12', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '13', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '14', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '15', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '16', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '17', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '18', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '19', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '20', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '21', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '22', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '23', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '24', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '25', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '26', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '27', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '28', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '29', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '30', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '31', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                        </select>                                                 
                                    </div>                                             
                                </div>                                         
                                <div class="span3"> 
                                    <div class="row-fluid"> 
                                        <select name="year" class="selectpicker span12"> 
                                            <option>
                                                <?php _e( 'Year', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '2009', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '2010', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '2011', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '2012', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '2013', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '2014', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '2015', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '2016', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '2017', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                            <option>
                                                <?php _e( '2018', 'hotel_of_ice' ); ?>
                                            </option>                                                     
                                        </select>                                                 
                                    </div>                                             
                                </div>                                         
                            </div>                                     
                            <div class="row-fluid"> 
                                <div class="span12"> 
                                    <label class="no">
                                        <?php _e( 'Name', 'hotel_of_ice' ); ?>
                                    </label>                                             
                                    <input type="text" name="name" placeholder="Name"> 
                                </div>                                         
                            </div>                                     
                            <div class="row-fluid"> 
                                <div class="span12"> 
                                    <label class="no">
                                        <?php _e( 'Enter your Email', 'hotel_of_ice' ); ?>
                                    </label>                                             
                                    <input name="pass" type="email" placeholder="Enter your Email"> 
                                </div>                                         
                            </div>                                     
                            <div class="formFoot"> 
                                <button type="submit" class="btn">
                                    <?php _e( 'Book today', 'hotel_of_ice' ); ?>
                                </button>                                         
                                <span class="leftSide"> </span> 
                                <span class="rightSide"> </span> 
                            </div>                                     
                            <span class="help-block text-center footForm"><?php _e( 'By signing up you agree our', 'hotel_of_ice' ); ?> <a href="#"><?php _e( 'Terms', 'hotel_of_ice' ); ?></a> <?php _e( 'and', 'hotel_of_ice' ); ?> <a href="#"><?php _e( 'Privacy Policy', 'hotel_of_ice' ); ?></a></span> 
                        </fieldset>                                 
                    </form>                             
                </div>                         
            </div>                     
        </div>                 
    </div>             
</section>
<?php if ( have_posts() ) : ?>
    <?php while ( have_posts() ) : the_post(); ?>
        <div>
            <section class="items tips first generic-section  text-center"> 
                <div class="container"> 
                    <h2 class="left"><?php _e( 'A Perfect hotel boutique landing page', 'hotel_of_ice' ); ?></h2> 
                    <p class="intro-text right"><em><?php _e( 'Whether it is your annual holiday vacation, a romantic weekend getaway or just a mid-week escape from', 'hotel_of_ice' ); ?> <br> <?php _e( 'Boston or New York, the Miami Plaza Hotel has a lot to offer.', 'hotel_of_ice' ); ?></em></p> 
                    <div class="clear"></div>                             
                    <div class="row-fluid bottom"> 
                        <div class="span3 item first"> 
                            <span class="ico"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/features/ico1.png" alt="icon" /></span> 
                            <h4><?php _e( 'Restaurants', 'hotel_of_ice' ); ?> </h4> 
                            <p><?php _e( 'You can register and create your profile for FREE! Lorem ipsum dolor sit amet, consecteturo eiusmod tempor.', 'hotel_of_ice' ); ?></p> 
                        </div>                                 
                        <div class="span3 item second"> 
                            <span class="ico"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/features/ico2.png" alt="icon" /></span> 
                            <h4><?php _e( 'Spa and Jacuzzi', 'hotel_of_ice' ); ?> </h4> 
                            <p><?php _e( 'You can register and create your profile for FREE! Lorem ipsum dolor sit amet, consecteturo eiusmod tempor.', 'hotel_of_ice' ); ?></p> 
                        </div>                                 
                        <div class="span3 item third"> 
                            <span class="ico"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/features/ico3.png" alt="icon" /></span> 
                            <h4><?php _e( 'Casino', 'hotel_of_ice' ); ?></h4> 
                            <p><?php _e( 'You can register and create your profile for FREE! Lorem ipsum dolor sit amet, consecteturo eiusmod tempor.', 'hotel_of_ice' ); ?></p> 
                        </div>                                 
                        <div class="span3 item last"> 
                            <span class="ico"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/features/ico4.png" alt="icon" /></span> 
                            <h4><?php _e( 'Nightclub', 'hotel_of_ice' ); ?></h4> 
                            <p><?php _e( 'You can register and create your profile for FREE! Lorem ipsum dolor sit amet, consecteturo eiusmod tempor.', 'hotel_of_ice' ); ?></p> 
                        </div>                                 
                    </div>                             
                </div>                         
            </section>
            <section class="items tips why generic-section  text-center"> 
                <div class="container"> 
                    <h2 class="left"><?php _e( 'accomodations', 'hotel_of_ice' ); ?></h2> 
                    <p class="intro-text right"><em><?php _e( 'All accommodations include a bountiful continental breakfast and afternoon tea. Complimentary high speed', 'hotel_of_ice' ); ?><br> <?php _e( 'wireless internet access is available throughout the property and a loan laptop is available on request.', 'hotel_of_ice' ); ?></em></p> 
                    <div class="clear"></div>                             
                    <div class="row-fluid bottom"> 
                        <div class="span3 item first"> 
                            <div class="avatar"> 
                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/why/img-1.jpg" alt="//" /> 
                                <span><em><?php _e( '$ 480', 'hotel_of_ice' ); ?></em></span> 
                            </div>                                     
                            <h4><?php _e( 'SINGLE ROOM', 'hotel_of_ice' ); ?></h4> 
                            <p><?php _e( 'A perfect choice for a single person. You will have access to all facilities and free breakfast delivered straight to you in the morning when you get up.', 'hotel_of_ice' ); ?></p> 
                        </div>                                 
                        <div class="span3 item second"> 
                            <div class="avatar"> 
                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/why/img-2.jpg" alt="//" /> 
                                <span><em><?php _e( '$ 580', 'hotel_of_ice' ); ?></em></span> 
                            </div>                                     
                            <h4><?php _e( 'DOUBLE ROOM', 'hotel_of_ice' ); ?></h4> 
                            <p><?php _e( 'Great choice for a couple. You will have access to all facilities and free breakfast delivered straight to you in the morning when sun is shining.', 'hotel_of_ice' ); ?></p> 
                        </div>                                 
                        <div class="span3 item third"> 
                            <div class="avatar"> 
                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/why/img-3.jpg" alt="//" /> 
                                <span><em><?php _e( '$ 680', 'hotel_of_ice' ); ?></em></span> 
                            </div>                                     
                            <h4><?php _e( 'LUXURY SUITE', 'hotel_of_ice' ); ?></h4> 
                            <p><?php _e( 'Perfect for our most demanding guests. You will have access to all facilities and free breakfast delivered straight to you in the morning with a gazette.', 'hotel_of_ice' ); ?></p> 
                        </div>                                 
                        <div class="span3 item third"> 
                            <div class="avatar"> 
                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/why/img-4.jpg" alt="//" /> 
                                <span><em><?php _e( '$ 980', 'hotel_of_ice' ); ?></em></span> 
                            </div>                                     
                            <h4><?php _e( 'LUXURY SUITE', 'hotel_of_ice' ); ?></h4> 
                            <p><?php _e( 'A perfect choice for a single person. You will have access to all facilities and free breakfast delivered straight to you in the morning when you get up.', 'hotel_of_ice' ); ?></p> 
                        </div>                                 
                    </div>                             
                </div>                         
            </section>
            <section class="testimonials"> 
                <div class="container"> 
                    <div class="row-fluid bottom"> 
                        <div class="span12"> 
                            <ul class="list-testimonials" id="slider2"> 
                                <li> 
                                    <img class="img-circle" src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/testimonials/img-avatar.png" alt="testimonial image" /> 
                                    <p class="comment"><?php _e( '“Want to meet singles with similar interests? Explore Cupid, the social dating service based on the common interests people share online. ”', 'hotel_of_ice' ); ?></p> 
                                    <p class="date"> <span></span> <?php _e( 'Mike &amp; Angelina', 'hotel_of_ice' ); ?> </p> 
                                </li>                                         
                                <li> 
                                    <img class="img-circle" src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/testimonials/img-avatar-2.png" alt="testimonial image" /> 
                                    <p class="comment"><?php _e( '“Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy tex”', 'hotel_of_ice' ); ?></p> 
                                    <p class="date"> <span></span> <?php _e( 'Mike &amp; Angelina', 'hotel_of_ice' ); ?> </p> 
                                </li>                                         
                            </ul>                                     
                        </div>                                 
                    </div>                             
                </div>                         
            </section>
            <section class="video generic-section  text-center"> 
                <div class="container"> 
                    <h2 class="left"><?php _e( 'hotel complete video tour', 'hotel_of_ice' ); ?></h2> 
                    <p class="intro-text right"><em><?php _e( 'Etiam in ornare lacus. Vivamus urna tellus, bibendum posuere elementum in, vehicula vel massa.', 'hotel_of_ice' ); ?><br> <?php _e( 'Aliquam ac scelerisque nunc. Donec ullamcorper non tellus in fringilla.', 'hotel_of_ice' ); ?> </em></p> 
                    <div class="row-fluid"> 
                        <div class="span7 left"> 
                            <div id="video"> 
                                <iframe width="800" height="450" src="http://player.vimeo.com/video/27764822?title=0&amp;byline=0&amp;portrait=0&amp;color=4584be"></iframe>                                         
                            </div>                                     
                        </div>                                 
                        <div class="span5 right"> 
                            <ul class="list-features text-left"> 
                                <li>
                                    <?php _e( 'The social dating service based on your interests', 'hotel_of_ice' ); ?>
                                </li>                                         
                                <li>
                                    <?php _e( 'Find new matches quickly and easily by interests', 'hotel_of_ice' ); ?>
                                </li>                                         
                                <li>
                                    <?php _e( 'Location based dating', 'hotel_of_ice' ); ?>
                                </li>                                         
                                <li>
                                    <?php _e( 'Explore new places, events and real people near you', 'hotel_of_ice' ); ?>
                                </li>                                         
                                <li>
                                    <?php _e( 'Social dating site that helps you to meet matches by interests', 'hotel_of_ice' ); ?>
                                </li>                                         
                                <li>
                                    <?php _e( 'You can customize and filter your search to exactly what you need', 'hotel_of_ice' ); ?>
                                </li>                                         
                                <li>
                                    <?php _e( 'Explore new places, events and real people near you', 'hotel_of_ice' ); ?>
                                </li>                                         
                                <li>
                                    <?php _e( 'Social dating site that helps you to meet matches by interests', 'hotel_of_ice' ); ?>
                                </li>                                         
                            </ul>                                     
                        </div>                                 
                    </div>                             
                </div>                         
            </section>
            <section class="generic-section wall text-center"> 
                <div class="container"> 
                    <h2 class="keft"><?php _e( 'see all hotel images here', 'hotel_of_ice' ); ?></h2> 
                    <p class="intro-text right"><em><?php _e( 'Etiam in ornare lacus. Vivamus urna tellus, bibendum posuere elementum in, vehicula vel massa.', 'hotel_of_ice' ); ?><br> <?php _e( 'Aliquam ac scelerisque nunc. Donec ullamcorper non tellus in fringilla. Follow us on Pinterest!', 'hotel_of_ice' ); ?></em></p> 
                </div>                         
                <div class="row-fluid"> 
                    <div id="screenshot" class="span12"> 
                        <div class="row-fluid bottom"> 
                            <div class="span12"> 
                                <div id="ri-grid" class="ri-grid ri-grid-size-2"> 
                                    <img class="ri-loading-image" src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/loading.gif" alt="//" /> 
                                    <ul> 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/1.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/2.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/3.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/4.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/5.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/6.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/7.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/8.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/9.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/10.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/11.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/12.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/13.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/14.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/15.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/16.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/17.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/18.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/19.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/20.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/21.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/22.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/23.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/24.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/25.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/26.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/27.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/28.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/29.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/30.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/31.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/32.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/33.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/34.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/35.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/36.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/37.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/38.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/39.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/40.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/41.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/42.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/43.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/44.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/45.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/46.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/47.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/48.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/49.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/50.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/51.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/52.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/53.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                        <li>
                                            <a href="#">
                                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/medium/54.jpg" alt="//" />
                                            </a>
                                        </li>                                                 
                                    </ul>                                             
                                </div>                                         
                            </div>                                     
                        </div>                                 
                    </div>                             
                </div>                         
            </section>
            <section class="generic-section pricing text-center"> 
                <div class="container"> 
                    <h2 class="left"><?php _e( 'hotel packages', 'hotel_of_ice' ); ?></h2> 
                    <p class="intro-text right"><em><?php _e( 'Etiam in ornare lacus. Vivamus urna tellus, bibendum posuere elementum in, vehicula vel massa.', 'hotel_of_ice' ); ?> <br> <?php _e( 'Aliquam ac scelerisque nunc. Donec ullamcorper non tellus in fringilla. Ut placerat velit tellus, sed scelerisque lorem.', 'hotel_of_ice' ); ?></em></p> 
                    <div class="row-fluid"> 
                        <div class="span4 item left"> 
                            <h3><em><?php _e( 'Stay 3 nights or more and 3rd night is on us', 'hotel_of_ice' ); ?></em></h3> 
                            <p><?php _e( 'The best things comes in threes!  Now through September 30th every 3rd is free.  Reserve three or more nights and EPIC will cover your third night.   Yes, you\'re third night is free!', 'hotel_of_ice' ); ?></p> 
                            <h6><?php _e( '** Valid for stays beginning May 1- September 30, 2013. Blackout dates may apply. **', 'hotel_of_ice' ); ?></h6> 
                            <a href="" class="btn btn-large"><?php _e( 'book now', 'hotel_of_ice' ); ?></a> 
                        </div>                                 
                        <div class="span4 item bottom"> 
                            <h3><em><?php _e( 'Bed & Breakfast in the Magic City', 'hotel_of_ice' ); ?></em></h3> 
                            <p><?php _e( 'The best things comes in threes!  Now through September 30th every 3rd is free.  Reserve three or more nights and EPIC will cover your third night.   Yes, you\'re third night is free!', 'hotel_of_ice' ); ?></p> 
                            <h6><?php _e( '** Valid for stays beginning May 1- September 30, 2013. Blackout dates may apply. **', 'hotel_of_ice' ); ?></h6> 
                            <a href="" class="btn btn-large"><?php _e( 'book now', 'hotel_of_ice' ); ?></a> 
                        </div>                                 
                        <div class="span4 item right"> 
                            <h3><em><?php _e( 'Florida Resident Park and Play', 'hotel_of_ice' ); ?></em></h3> 
                            <p><?php _e( 'The best things comes in threes!  Now through September 30th every 3rd is free.  Reserve three or more nights and EPIC will cover your third night.   Yes, you\'re third night is free!', 'hotel_of_ice' ); ?></p> 
                            <h6><?php _e( '** Valid for stays beginning May 1- September 30, 2013. Blackout dates may apply. **', 'hotel_of_ice' ); ?></h6> 
                            <a href="#" class="btn btn-large"><?php _e( 'book now', 'hotel_of_ice' ); ?></a> 
                        </div>                                 
                    </div>                             
                </div>                         
            </section>
        </div>
    <?php endwhile; ?>
<?php else : ?>
    <p><?php _e( 'Sorry, no posts matched your criteria.', 'hotel_of_ice' ); ?></p>
<?php endif; ?>
<section class="newsletter"> 
    <div class="container"> 
        <div class="row-fluid"> 
            <div class="span12"> 
                <form id="newsletter" class="formNewsletter nm" action="<?php echo esc_url( get_template_directory_uri() ); ?>/index_submit" method="post" accept-charset="utf-8"> 
                    <div id="loadingNews" style="display: none" class='alert'> 
                        <a class='close' data-dismiss='alert'><?php _e( '×', 'hotel_of_ice' ); ?></a>
                        <?php _e( 'Loading', 'hotel_of_ice' ); ?> 
                    </div>                             
                    <div id="responseNews"></div>                             
                    <div class="row-fluid"> 
                        <div class="span12 fields"> 
                            <label class="left">
                                <?php _e( 'Stay in touch by email for updates and offers', 'hotel_of_ice' ); ?>
                            </label>                                     
                            <div class="right"> 
                                <input type="text" class="large" placeholder="Your email here..." name="Email" value="" /> 
                                <input class="btn btn-large btn-primary" type="submit" name="submit" value="SUSCRIBE NOW" id="submit" /> 
                            </div>                                     
                        </div>                                 
                    </div>                             
                </form>                         
            </div>                     
        </div>                 
    </div>             
</section>
<div class="footer"> 
    <section class="container generic-section"> 
        <div class="row-fluid"> 
            <div class="span3 item left"> 
                <h3><?php echo get_post_meta( get_the_ID(), 'footer1_title', true ); ?></h3> 
                <p><?php echo get_post_meta( get_the_ID(), 'footer1_text', true ); ?></p> 
                <p><?php _e( 'Ligula vel diam congue semper.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus', 'hotel_of_ice' ); ?></p> 
            </div>                     
            <div class="span3 item left"> 
                <h3><?php echo get_post_meta( get_the_ID(), 'footer2_title', true ); ?></h3> 
                <p><?php echo get_post_meta( get_the_ID(), 'footer2_text', true ); ?></p> 
            </div>                     
            <div class="span3 item right"> 
                <h3><?php echo get_post_meta( get_the_ID(), 'footer3_title', true ); ?></h3> 
                <p><a href="#"><?php _e( '+ Luxury Suite', 'hotel_of_ice' ); ?></a></p> 
                <p><a href="#"><?php _e( '+ Double Suite', 'hotel_of_ice' ); ?></a></p> 
                <p><a href="#"><?php _e( '+ Luxury Suite', 'hotel_of_ice' ); ?></a></p> 
                <p><a href="#"><?php _e( '+ Single Suite', 'hotel_of_ice' ); ?></a></p> 
                <p><a href="#"><?php _e( '+ Casino Resort', 'hotel_of_ice' ); ?></a></p> 
            </div>                     
            <div class="span3 item right"> 
                <h3><?php echo get_post_meta( get_the_ID(), 'footer4_title', true ); ?></h3> 
                <p><?php echo get_post_meta( get_the_ID(), 'footer4_text', true ); ?></p> 
                <ul class="social"> 
                    <li class="tooltip_hover" title="" data-original-title="Linkedin">
                        <a href="<?php echo get_post_meta( get_the_ID(), 'social_linkedin', true ); ?>" class="in"><?php _e( 'Linked In', 'hotel_of_ice' ); ?></a>
                    </li>                             
                    <li class="tooltip_hover" title="" data-original-title="Youtube">
                        <a href="<?php echo get_post_meta( get_the_ID(), 'social_youtube', true ); ?>" class="youtube"><?php _e( 'Linked In', 'hotel_of_ice' ); ?></a>
                    </li>                             
                    <li class="tooltip_hover" title="" data-original-title="Facebook">
                        <a href="<?php echo get_post_meta( get_the_ID(), 'social_facebook', true ); ?>" class="facebook"><?php _e( 'Linked In', 'hotel_of_ice' ); ?></a>
                    </li>                             
                    <li class="tooltip_hover" title="" data-original-title="Twitter">
                        <a href="<?php echo get_post_meta( get_the_ID(), 'social_twitter', true ); ?>" class="twitter"><?php _e( 'Linked In', 'hotel_of_ice' ); ?></a>
                    </li>                             
                </ul>                         
            </div>                     
        </div>                 
    </section>             
</div>         
<!-- Slider -->                  
<!-- End Slider -->         
<!-- Features -->         
<!-- .container -->         
<!-- end Features -->         
<!-- Why -->         
<!-- .container -->         
<!-- end Why -->         
<!--Testimonials-->                  
<!--End Testimonials-->         
<!--Video List-->                  
<!--End Video List-->         
<!--Image Gallery-->                  
<!-- End Image Gallery-->         
<!--Pricing-->                  
<!-- end pricing -->         
<!--Newsletter-->                  
<!--End Newsletter-->         
<!--Footer-->         
<!-- End Footer -->         
<!--Copyright-->         
<div class="copy"> 
    <section class="container"> 
        <p><?php _e( '© Copyright © 2015 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus et justo nec arc.', 'hotel_of_ice' ); ?></p> 
    </section>             
</div>         
<!--End Copyright-->         
<!-- ======================= JQuery libs =========================== -->                  
<!-- Bootstrap.js-->                           
<!-- Gallery -->                           
<!-- Slider -->                  
<!-- Controls styles -->                  
<!-- Video Responsive-->                  
<!-- easing plugin ( optional ) -->                  
<!-- UItoTop plugin -->                  
<!--  Waypoints -->                  
<!-- Template custom script  -->                  
<!-- ======================= End JQuery libs ======================= -->                 

<?php get_footer(); ?>